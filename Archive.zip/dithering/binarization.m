function [ output_args ] = binarization(im, level)
    

end

