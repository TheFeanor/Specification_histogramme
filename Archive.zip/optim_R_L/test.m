[u, lambda] = uzawa(h, [0.5, 0.5], [1,1,1,1,1,1], 100, 500);
% h: histogram
% RL de depart
% les lambdas de depart
% N: uzawa
%n: descente de gradient dans la m�thode d'uzawa